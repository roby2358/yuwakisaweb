# Riverworld

A long-haul journey game after Philip José Farmer's *Riverworld*. Everyone who ever
died wakes on the banks of a River without end; grailstones feed whoever sets a grail
on them, and sometimes leave a little more. Somewhere upriver is the reason for all
of it.

**There is no win and no game over — only distance.** Death is *translation*: you wake
somewhere on the stretch of river you know, owning nothing but your grail and
everything you've learned. The chart, your languages, and the Strangers' gifts persist
forever; boats, crews, and cargo are mortal. The game is built for recurring play — the
save persists in the browser, and the ladder (furthest reach, chart, boons, the roster
of the famous dead you've sailed with) climbs across many sessions and many deaths.

## Running

No build, no server: **double-click `index.html`**. Progress autosaves to
localStorage every day. "New Life" wipes the save.

## How to play

- **One turn = one day.** Each morning the grailstone feeds you and drops a random
  luxury — cigars, liquor, cloth, dreamgum, rarely a lighter. Luxuries are the only
  money; your purse is what they'd fetch *here*.
- **Travel upriver** toward the milestones (gold stars). The current stiffens and the
  grailstones thin out the further you go — provision food for the dead stretches.
- **Bank polities** (colored blocks on the chart) trade, recruit, teach languages,
  sell rumors, and build boats. Their economy and temper are visible once charted:
  trade hubs, builders, theocracies, warlords — and slavers, who'd rather keep you.
- **Wealth is heat.** A rich boat draws pirates. Spend it, bank it into a better hull,
  or lose it.
- **Crew are the historical dead** — Mark Twain pilots, Harriet Tubman gets you out of
  chains. Anyone you lose is only *translated*: watch the banks, the River gives
  people back.
- **The Suicide Express** is always one button away: die on purpose, wake somewhere
  random on the known river. Nearly free when you have nothing; unthinkable when you
  have everything.

Design rationale — theme, drivers, strategies, tuning — lives in `DYNAMICS.md`.
