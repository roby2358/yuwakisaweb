// ui.js — canvas river ribbon + action panels. All rendering rebuilds from
// state; one delegated click handler dispatches data-action attributes.

const UI = {
    state: null,
    viewStart: 0,       // leftmost reach index drawn
    follow: true,
    suicideArmed: false,
    lastDeaths: 0,
    inspect: null,      // reach index under cursor / clicked
    CW: 26,             // cell width px
};

const ZONE_TINTS = ['#3f6d3a', '#42663d', '#5d6136', '#5e5c4a', '#4e5560', '#3d4652'];
const TEMPER_COLORS = { open: '#7fd07f', wary: '#e0c95f', hostile: '#e06a5f' };

function uiInit(state) {
    UI.state = state;
    UI.lastDeaths = state.deaths;
    const canvas = document.getElementById('river');
    canvas.addEventListener('mousemove', e => {
        UI.inspect = reachAtX(e.offsetX);
        renderInspect();
    });
    canvas.addEventListener('mouseleave', () => { UI.inspect = null; renderInspect(); });
    canvas.addEventListener('wheel', e => {
        e.preventDefault();
        UI.follow = false;
        UI.viewStart = Math.max(0, UI.viewStart + Math.sign(e.deltaY || e.deltaX) * 3);
        drawRiver();
    }, { passive: false });
    document.body.addEventListener('click', onAction);
    window.addEventListener('resize', () => render());
    render();
}

function reachAtX(x) {
    return UI.viewStart + Math.floor(x / UI.CW);
}

function visibleCells() {
    const canvas = document.getElementById('river');
    return Math.floor(canvas.width / UI.CW);
}

// ---------- action dispatch ----------

function onAction(e) {
    const btn = e.target.closest('[data-action]');
    if (!btn || btn.disabled) return;
    const s = UI.state;
    const [action, arg] = btn.dataset.action.split(':');
    const acts = {
        up: () => actTravel(s, +1),
        down: () => actTravel(s, -1),
        rest: () => actRest(s),
        raft: () => actBuildRaft(s),
        repair: () => actRepair(s),
        rumor: () => actBuyRumor(s),
        lesson: () => actLearnLanguage(s),
        heal: () => actHeal(s),
        recruit: () => actRecruit(s),
        toil: () => actToil(s),
        plot: () => actPlot(s),
        buyfood: () => actBuyFood(s, Number(arg)),
        buyweap: () => actBuyWeapons(s, Number(arg)),
        buyboat: () => actBuyBoat(s, Number(arg)),
        event: () => resolvePendingEvent(s, Number(arg)),
        boon: () => chooseBoon(s, arg),
        suicide: () => {
            if (!UI.suicideArmed) { UI.suicideArmed = true; render(); return; }
            UI.suicideArmed = false;
            actSuicide(s);
        },
        unsuicide: () => { UI.suicideArmed = false; },
        panleft: () => { UI.follow = false; UI.viewStart = Math.max(0, UI.viewStart - 10); },
        panright: () => { UI.follow = false; UI.viewStart += 10; },
        center: () => { UI.follow = true; },
        dismissdeath: () => { document.getElementById('death-panel').classList.add('hidden'); },
        begin: () => { document.getElementById('intro-panel').classList.add('hidden'); },
        newgame: () => {
            if (!confirm('Abandon this life entirely? The River forgets you. (Deletes the save.)')) return;
            clearSave();
            UI.state = newState(Math.floor(Math.random() * 0xffffffff));
            UI.lastDeaths = 0;
            chartReach(UI.state, 0);
            saveState(UI.state);
        },
    };
    if (!acts[action]) return;
    acts[action]();
    if (action !== 'suicide') UI.suicideArmed = false;
    if (UI.state.deaths > UI.lastDeaths) {
        UI.lastDeaths = UI.state.deaths;
        showDeathPanel();
    }
    render();
}

function showDeathPanel() {
    const p = document.getElementById('death-panel');
    const last = UI.state.journal.filter(j => j.includes('Died:')).pop() || '';
    document.getElementById('death-text').textContent =
        `${last} You wake naked on the bank of reach ${UI.state.reach}, grail in hand. ` +
        `The chart, your tongues, and the Stranger's gifts remain. Nothing else does.`;
    p.classList.remove('hidden');
}

// ---------- render ----------

function render() {
    const s = UI.state;
    if (UI.follow) {
        UI.viewStart = Math.max(0, s.reach - Math.floor(visibleCells() / 2));
    }
    drawRiver();
    renderStatus();
    renderHere();
    renderActions();
    renderCrew();
    renderCargo();
    renderLog();
    renderModal();
    renderInspect();
}

function renderStatus() {
    const s = UI.state;
    const boat = BOATS[s.boat.tier];
    const zone = zoneOf(s.reach);
    document.getElementById('status').innerHTML = [
        `Day ${s.day}`,
        `Reach ${s.reach} <span class="dim">(${zone.name})</span>`,
        `HP ${'♥'.repeat(s.hp)}${'<span class="dim">♡</span>'.repeat(Math.max(0, MAX_HP - s.hp))}`,
        `Food ${s.cargo.food}`,
        `${boat.name}${s.boat.hurt ? ' <span class="bad">(damaged)</span>' : ''}`,
        `Crew ${s.crew.length}/${crewCapacity(s)}`,
        `Cargo ${cargoUsed(s)}/${cargoCapacity(s)}`,
        `Force ${playerForce(s)}`,
        `Heat ${heat(s)}`,
        `Furthest ${s.furthest}`,
        `Deaths ${s.deaths}`,
    ].map(x => `<span class="stat">${x}</span>`).join('');
}

function renderHere() {
    const s = UI.state;
    const r = actualReach(s, s.reach);
    const el = document.getElementById('here');
    if (s.enslaved) {
        el.innerHTML = `<h3 class="bad">Enslaved</h3><p>A grail-slave. Fed enough to live, kept for what the grail yields. Toil, plot, or take the one door that is always open.</p>`;
        return;
    }
    if (!r.polity) {
        el.innerHTML = `<h3>Wilds — reach ${s.reach}</h3><p>${r.deadStone
            ? '<span class="bad">The grailstone here is dead.</span> Stores feed you or nothing does.'
            : 'A live grailstone among the grass. Food is free here.'}${r.milestone ? '<br><span class="gold">A zone boundary — the air itself feels watched.</span>' : ''}</p>`;
        return;
    }
    const econ = ECONOMIES[r.polity.economy];
    const fam = LANG_FAMILIES.find(f => f.id === r.polity.lang);
    const spoken = speaks(s, r);
    const demand = s.demand[s.reach] !== undefined ? s.demand[s.reach] : 1.0;
    el.innerHTML = `
        <h3>${r.polity.name} <span class="dim">— ${econ.name}, ${TEMPERS[r.polity.temper].name.toLowerCase()}</span></h3>
        <p>Tongue: ${fam.name} ${spoken ? '<span class="good">(you speak it — better prices)</span>' : '<span class="dim">(foreign to you)</span>'}
        · Market demand ${(demand * 100).toFixed(0)}%
        · Your purse here: <b>${localPurse(s, s.reach).toFixed(1)}</b> value</p>
        ${econ.bansGum ? '<p class="dim">Dreamgum is banned here; it counts for nothing in trade.</p>' : ''}
        ${econ.pressgang ? '<p class="bad">Grail-slavers work these docks. Linger at your peril.</p>' : ''}`;
}

function renderActions() {
    const s = UI.state;
    const el = document.getElementById('actions');
    const busy = s.pendingEvent || s.pendingBoon;
    const r = actualReach(s, s.reach);
    const rows = [];
    const B = (action, label, detail, disabled) =>
        `<button data-action="${action}" ${disabled || busy ? 'disabled' : ''}>${label}${detail ? ` <span class="detail">${detail}</span>` : ''}</button>`;

    if (s.enslaved) {
        rows.push(B('toil', 'Toil', 'keep your head down'));
        const chance = Math.round(100 * (0.20 + 0.05 * s.enslaved.plots + (s.lostSouls.some(c => c.ability === 'liberator') ? 0.25 : 0)));
        rows.push(B('plot', 'Plot escape', `~${chance}% — failure risks a beating`));
    } else {
        rows.push(B('up', `▲ Upriver`, `${effSpeedUp(s)} reach${effSpeedUp(s) > 1 ? 'es' : ''}/day`));
        rows.push(B('down', `▼ Downriver`, `${Math.min(s.reach, effSpeedDown(s))} reaches/day`, s.reach === 0));
        rows.push(B('rest', 'Rest a day', s.hp < MAX_HP ? '+1 HP' : 'pass the time'));
        if (s.boat.tier === 0) rows.push(B('raft', 'Build a raft', '1 day, free'));
        if (s.boat.hurt) rows.push(B('repair', 'Repair the boat', '1 day'));
        if (r.polity) {
            const econ = ECONOMIES[r.polity.economy];
            const purse = localPurse(s, s.reach);
            const full = cargoUsed(s) >= cargoCapacity(s);
            rows.push('<hr>');
            const foodP = buyPrice(s, s.reach, 'food');
            rows.push(B('buyfood:1', 'Buy food ×1', `${foodP.toFixed(1)}v`, purse < foodP || full));
            rows.push(B('buyfood:5', 'Buy food ×5', `${(foodP * 5).toFixed(1)}v`, purse < foodP * 5 || cargoUsed(s) + 5 > cargoCapacity(s)));
            if (econ.buys.weapons !== undefined) {
                const wp = buyPrice(s, s.reach, 'weapons');
                rows.push(B('buyweap:1', 'Buy weapon ×1', `${wp.toFixed(1)}v, +1 force`, purse < wp || full));
            }
            if (econ.buys.rumor !== undefined) {
                const rp = buyPrice(s, s.reach, 'rumor');
                rows.push(B('rumor', 'Buy rumors', `${rp.toFixed(1)}v + 1 day — charts ${RUMOR_RANGE} reaches ahead`, purse < rp));
            }
            if (!s.languages.includes(r.polity.lang) && !hasBoon(s, 'tongues')) {
                const lp = buyPrice(s, s.reach, 'language');
                const days = hasAbility(s, 'linguist') ? 1 : 3;
                rows.push(B('lesson', 'Language lessons', `${lp.toFixed(1)}v + ${days} day${days > 1 ? 's' : ''}`, purse < lp));
            }
            if (econ.buys.heal !== undefined && s.hp < MAX_HP) {
                const hp = buyPrice(s, s.reach, 'heal') * (MAX_HP - s.hp);
                rows.push(B('heal', 'Healers', `${hp.toFixed(1)}v + 1 day — full HP`, purse < hp));
            }
            const offer = getDockOffer(s);
            if (offer) {
                const rp = buyPrice(s, s.reach, 'recruit');
                rows.push(B('recruit', `Recruit ${offer.crew.name}`, `${ABILITIES[offer.crew.ability].name} — ${rp.toFixed(1)}v + 1 day`, purse < rp));
            }
            if (r.polity.economy === 'builder') {
                rows.push('<hr>');
                for (const b of BOATS) {
                    if (b.tier <= s.boat.tier || b.price === 0) continue;
                    const cost = b.price * TEMPERS[r.polity.temper].priceMult * (speaks(s, r) ? 0.75 : 1);
                    rows.push(B(`buyboat:${b.tier}`, `Buy ${b.name}`, `${cost.toFixed(0)}v + 1 day — spd ${b.speed}, cargo ${b.cargo}, crew ${b.crew}`, purse < cost));
                }
            }
        }
    }
    rows.push('<hr>');
    if (UI.suicideArmed) {
        rows.push(`<button class="grim armed" data-action="suicide" ${busy ? 'disabled' : ''}>Yes. Take the Express.</button>`);
        rows.push(`<button data-action="unsuicide">…no. Not today.</button>`);
    } else {
        rows.push(`<button class="grim" data-action="suicide" ${busy ? 'disabled' : ''}>The Suicide Express <span class="detail">die; wake somewhere on the known river</span></button>`);
    }
    el.innerHTML = rows.join('');
}

function renderCrew() {
    const s = UI.state;
    const el = document.getElementById('crew');
    const rows = s.crew.map(c =>
        `<div class="crewrow"><b>${c.name}</b> <span class="dim">${ABILITIES[c.ability].name} — ${ABILITIES[c.ability].desc}</span></div>`);
    if (!rows.length) rows.push('<div class="dim">No crew. The River is large and you are small.</div>');
    if (s.lostSouls.length) {
        rows.push(`<div class="dim souls">${s.lostSouls.length} lost soul${s.lostSouls.length > 1 ? 's' : ''} somewhere on the River: ${s.lostSouls.map(c => c.name).join(', ')}. Watch the banks.</div>`);
    }
    el.innerHTML = `<h3>Crew</h3>` + rows.join('');
}

function renderCargo() {
    const s = UI.state;
    const el = document.getElementById('cargo');
    const items = [];
    items.push(`<span>Food ${s.cargo.food}</span>`);
    if (s.cargo.weapons) items.push(`<span>Weapons ${s.cargo.weapons}</span>`);
    for (const l of LUXURIES) {
        if (s.cargo[l.id]) items.push(`<span>${l.name} ${s.cargo[l.id]} <span class="dim">(${l.value}v)</span></span>`);
    }
    const langs = s.languages.map(id => LANG_FAMILIES.find(f => f.id === id).name);
    const boons = s.boons.map(b => `<span class="gold" title="${BOONS[b].desc}">${BOONS[b].name}</span>`);
    el.innerHTML = `<h3>Grail &amp; Cargo</h3><div class="cargolist">${items.join('')}</div>
        <h3>Tongues</h3><div class="cargolist">${langs.length ? langs.map(x => `<span>${x}</span>`).join('') : '<span class="dim">none yet</span>'}</div>
        <h3>The Stranger's Gifts</h3><div class="cargolist">${boons.length ? boons.join('') : '<span class="dim">none yet — the zone boundaries are watched</span>'}</div>`;
}

function renderLog() {
    const el = document.getElementById('log');
    el.innerHTML = UI.state.log.slice(-40).map(l => `<div>${l}</div>`).join('');
    el.scrollTop = el.scrollHeight;
}

function renderInspect() {
    const el = document.getElementById('inspect');
    const s = UI.state;
    const i = UI.inspect;
    if (i === null || i < 0) { el.textContent = '· drag/scroll the chart · the dark reaches are uncharted ·'; return; }
    if (!isCharted(s, i)) { el.textContent = `Reach ${i} — uncharted. ${zoneOf(i).name}.`; return; }
    const k = s.chart[i];
    if (k.polity) {
        const fam = LANG_FAMILIES.find(f => f.id === k.polity.lang);
        el.textContent = `Reach ${i} — ${k.polity.name}: ${ECONOMIES[k.polity.economy].name}, ${k.polity.temper}, speaks ${fam.name}. ${zoneOf(i).name}. (charted — may have drifted)`;
    } else {
        el.textContent = `Reach ${i} — wilds${k.deadStone ? ', DEAD grailstone' : ', live grailstone'}. ${zoneOf(i).name}.`;
    }
}

function renderModal() {
    const s = UI.state;
    const modal = document.getElementById('modal');
    const body = document.getElementById('modal-body');
    if (s.pendingEvent) {
        const ev = describePendingEvent(s);
        body.innerHTML = `<p>${ev.text}</p>` + ev.choices.map((c, i) =>
            `<button data-action="event:${i}" ${c.disabled ? 'disabled' : ''}>${c.label}${c.detail ? ` <span class="detail">${c.detail}</span>` : ''}</button>`
        ).join('');
        modal.classList.remove('hidden');
    } else if (s.pendingBoon) {
        body.innerHTML = `<p>A Stranger sits at your fire, though no one saw him come. He does not eat.
            "You have come far. Choose." He offers a gift that death cannot take:</p>` +
            s.pendingBoon.map(b =>
                `<button data-action="boon:${b}"><b>${BOONS[b].name}</b> <span class="detail">${BOONS[b].desc}</span></button>`
            ).join('');
        modal.classList.remove('hidden');
    } else {
        modal.classList.add('hidden');
    }
}

// ---------- canvas ----------

function drawRiver() {
    const s = UI.state;
    const canvas = document.getElementById('river');
    canvas.width = canvas.clientWidth;
    canvas.height = 140;
    const ctx = canvas.getContext('2d');
    const cw = UI.CW, H = canvas.height;
    const bankH = 42, riverY = bankH, riverH = H - 2 * bankH;
    const cells = visibleCells() + 1;

    for (let c = 0; c < cells; c++) {
        const i = UI.viewStart + c;
        const x = c * cw;
        const zi = zoneIndexOf(i);
        const charted = isCharted(s, i);

        if (!charted) {
            ctx.fillStyle = '#15181d';
            ctx.fillRect(x, 0, cw, H);
            ctx.fillStyle = '#2a2f38';
            ctx.font = '12px monospace';
            ctx.fillText('?', x + cw / 2 - 3, riverY + riverH / 2 + 4);
        } else {
            const k = s.chart[i];
            // banks
            ctx.fillStyle = ZONE_TINTS[zi];
            ctx.fillRect(x, 0, cw, bankH);
            ctx.fillRect(x, H - bankH, cw, bankH);
            // river
            ctx.fillStyle = '#2c5670';
            ctx.fillRect(x, riverY, cw, riverH);
            ctx.fillStyle = 'rgba(255,255,255,0.06)';
            ctx.fillRect(x, riverY + ((i * 7) % riverH), cw, 2);

            if (k.polity) {
                ctx.fillStyle = ECONOMIES[k.polity.economy].color;
                ctx.fillRect(x + 3, 8, cw - 6, bankH - 16);
                ctx.strokeStyle = TEMPER_COLORS[k.polity.temper];
                ctx.lineWidth = 2;
                ctx.strokeRect(x + 3, 8, cw - 6, bankH - 16);
            } else if (k.deadStone) {
                ctx.fillStyle = '#555';
                ctx.beginPath();
                ctx.arc(x + cw / 2, bankH - 10, 4, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#333';
                ctx.beginPath();
                ctx.moveTo(x + cw / 2 - 5, bankH - 15);
                ctx.lineTo(x + cw / 2 + 5, bankH - 5);
                ctx.stroke();
            } else {
                ctx.fillStyle = '#9fb4c4';
                ctx.beginPath();
                ctx.arc(x + cw / 2, bankH - 10, 4, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        if (isMilestone(i)) {
            ctx.fillStyle = charted ? '#ffd700' : '#6b5b1e';
            ctx.font = '14px sans-serif';
            ctx.fillText('★', x + cw / 2 - 7, H - bankH + 26);
        }

        // zone boundary tick + label
        const z = ZONES.find(z => z.start === i);
        if (z) {
            ctx.strokeStyle = '#ffd70055';
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
            ctx.fillStyle = '#c9b458';
            ctx.font = '11px sans-serif';
            ctx.fillText(z.name, x + 4, H - 6);
        }
    }

    // the boat
    const bx = (s.reach - UI.viewStart) * cw + cw / 2;
    if (bx >= 0 && bx <= canvas.width) {
        ctx.fillStyle = s.enslaved ? '#e06a5f' : '#fff';
        ctx.beginPath();
        ctx.moveTo(bx, riverY + riverH / 2 - 8);
        ctx.lineTo(bx + 7, riverY + riverH / 2 + 6);
        ctx.lineTo(bx - 7, riverY + riverH / 2 + 6);
        ctx.closePath();
        ctx.fill();
    }

    // furthest marker
    const fx = (s.furthest - UI.viewStart) * cw + cw / 2;
    if (fx >= 0 && fx <= canvas.width && s.furthest > s.reach) {
        ctx.strokeStyle = '#ffffff44';
        ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(fx, riverY); ctx.lineTo(fx, riverY + riverH); ctx.stroke();
        ctx.setLineDash([]);
    }
}
