// river.js — the River is a pure function of (seed, index), plus a mutation
// overlay for world drift. Knowledge (the chart) is meaningful because the
// bones never change out from under it — only the overlay drifts.

function zoneIndexOf(i) {
    let z = 0;
    for (let k = 0; k < ZONES.length; k++) if (i >= ZONES[k].start) z = k;
    return z;
}
function zoneOf(i) { return ZONES[zoneIndexOf(i)]; }

// Milestone reaches: every zone boundary after the first.
function isMilestone(i) {
    return ZONES.some(z => z.start === i && z.start > 0);
}

function weightedHashPick(seed, i, salt, weights, ids) {
    let total = 0;
    for (const w of weights) total += w;
    let roll = hashRand(seed, i, salt) * total;
    for (let k = 0; k < ids.length; k++) {
        roll -= weights[k];
        if (roll <= 0) return ids[k];
    }
    return ids[ids.length - 1];
}

// The generated bones of a reach — deterministic, never stored.
function generateReach(seed, i) {
    const zi = zoneIndexOf(i);
    const zone = ZONES[zi];
    const reach = { index: i, zoneIndex: zi, polity: null, deadStone: false, milestone: isMilestone(i) };

    if (i === 0 || hashRand(seed, i, 'polity') < zone.polityChance) {
        const econId = i === 0 ? 'tradehub'
            : weightedHashPick(seed, i, 'econ', ECONOMY_W[zi], ECONOMY_IDS);
        const temperIds = Object.keys(zone.temperW);
        const temper = i === 0 ? 'open'
            : weightedHashPick(seed, i, 'temper', temperIds.map(t => zone.temperW[t]), temperIds);
        const fam = hashPick(seed, i, 'lang', LANG_FAMILIES);
        const name = hashPick(seed, i, 'npre', fam.pre) + hashPick(seed, i, 'nsuf', fam.suf);
        reach.polity = { name, economy: econId, temper, lang: fam.id };
    } else {
        reach.deadStone = hashRand(seed, i, 'stone') < zone.deadStone;
    }
    return reach;
}

// The reach as it actually is right now: bones + drift overlay.
// Mutations: { fallen: true } (polity gone, wilds now) or { temper: 'hostile' }.
function actualReach(state, i) {
    const base = generateReach(state.seed, i);
    const mut = state.riverMut[i];
    if (mut && base.polity) {
        if (mut.fallen) { base.polity = null; base.deadStone = false; }
        else if (mut.temper) base.polity.temper = mut.temper;
    }
    return base;
}

// Snapshot a reach into the chart (what the player believes).
function chartReach(state, i) {
    const r = actualReach(state, i);
    state.chart[i] = r.polity
        ? { polity: { name: r.polity.name, economy: r.polity.economy, temper: r.polity.temper, lang: r.polity.lang } }
        : { wilds: true, deadStone: r.deadStone };
}

function isCharted(state, i) { return state.chart[i] !== undefined; }

// Does the chart still match reality? (arrival surprise check)
function chartStale(state, i) {
    const known = state.chart[i];
    if (!known) return false;
    const r = actualReach(state, i);
    if (!!known.polity !== !!r.polity) return true;
    if (known.polity && r.polity && known.polity.temper !== r.polity.temper) return true;
    return false;
}
