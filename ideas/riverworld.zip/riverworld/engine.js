// engine.js — the day loop, ports, fights, slavery, death, and translation.
// DOM-free: the whole game can run headless (node sanity sims).
//
// A day: morning grail -> player action -> evening event -> world drift.
// pendingEvent / pendingBoon are serializable {id, params} — choices are
// rebuilt from the EVENTS registry, never stored.

// ---------- logging ----------

function log(state, msg) {
    state.log.push(`Day ${state.day}: ${msg}`);
    if (state.log.length > 100) state.log.shift();
}

function journal(state, msg) {
    state.journal.push(`Day ${state.day} — ${msg}`);
}

// ---------- derived numbers ----------

function boatOf(state) { return BOATS[state.boat.tier]; }

function hasAbility(state, ab) { return state.crew.some(c => c.ability === ab); }
function hasBoon(state, b) { return state.boons.includes(b); }

function cargoCapacity(state) {
    return boatOf(state).cargo + (hasAbility(state, 'quartermaster') ? 4 : 0);
}

function cargoUsed(state) {
    return Object.values(state.cargo).reduce((a, b) => a + b, 0);
}

function crewCapacity(state) { return boatOf(state).crew; }

function playerForce(state) {
    const fighters = state.crew.filter(c => c.ability === 'fighter').length;
    return 2 + 2 * fighters
        + Math.min(state.cargo.weapons, state.crew.length + 1)
        + boatOf(state).force
        + (hasBoon(state, 'oldsoldier') ? 2 : 0);
}

function effSpeedUp(state) {
    if (state.boat.hurt) return 1;
    const speed = boatOf(state).speed + (hasAbility(state, 'pilot') ? 1 : 0);
    return Math.max(1, speed - zoneOf(state.reach).current);
}

function effSpeedDown(state) {
    if (state.boat.hurt) return 1;
    return boatOf(state).speed + (hasAbility(state, 'pilot') ? 1 : 0)
        + zoneOf(state.reach).current + 1;
}

function purseValue(state) {
    return LUXURIES.reduce((sum, l) => sum + state.cargo[l.id] * l.value, 0);
}

function heat(state) {
    return boatOf(state).covet + Math.floor(purseValue(state) / 20);
}

function speaks(state, reach) {
    if (hasBoon(state, 'tongues')) return true;
    return !!(reach.polity && state.languages.includes(reach.polity.lang));
}

// ---------- trade math ----------

function sellPrice(state, i, luxId) {
    const r = actualReach(state, i);
    if (!r.polity) return 0;
    const econ = ECONOMIES[r.polity.economy];
    const demand = state.demand[i] !== undefined ? state.demand[i] : 1.0;
    let mult = econ.sellMult[luxId] * demand;
    if (speaks(state, r)) mult *= 1.25;
    if (hasAbility(state, 'linguist')) mult *= 1.10;
    return LUX_BY_ID[luxId].value * mult;
}

function buyPrice(state, i, item) {
    const r = actualReach(state, i);
    if (!r.polity) return Infinity;
    let mult = TEMPERS[r.polity.temper].priceMult;
    if (speaks(state, r)) mult *= 0.75;
    if (item === 'recruit' && hasAbility(state, 'orator')) mult *= 0.75;
    return PRICES[item] * mult;
}

// Purse valued at *local* sell prices — barter cuts both ways.
function localPurse(state, i) {
    return LUXURIES.reduce((sum, l) => sum + state.cargo[l.id] * sellPrice(state, i, l.id), 0);
}

// Pay `amount` of local value in luxuries, cheapest-per-unit first. Overpay allowed.
function spendValue(state, i, amount) {
    const order = LUXURIES.slice().sort((a, b) => sellPrice(state, i, a.id) - sellPrice(state, i, b.id));
    let owed = amount;
    for (const l of order) {
        const unit = sellPrice(state, i, l.id);
        if (unit <= 0) continue;
        while (owed > 0 && state.cargo[l.id] > 0) {
            state.cargo[l.id]--;
            owed -= unit;
        }
    }
    return owed <= 0.0001;
}

function noteDemand(state, i, valueSold) {
    const cur = state.demand[i] !== undefined ? state.demand[i] : 1.0;
    state.demand[i] = Math.max(0.4, cur - valueSold * 0.01);
}

// Lose luxuries totaling roughly `value` (raids, bribes-in-kind), highest value first.
function loseValue(state, value) {
    const order = LUXURIES.slice().sort((a, b) => b.value - a.value);
    let owed = value;
    for (const l of order) {
        while (owed > 0 && state.cargo[l.id] > 0) {
            state.cargo[l.id]--;
            owed -= l.value;
        }
    }
}

function gainLuxuries(state, value) {
    // random luxuries up to `value`, respecting cargo space
    let budget = value;
    let guard = 50;
    while (budget > 0 && guard-- > 0) {
        const l = randoWeighted(LUXURIES);
        if (l.value > budget && budget < 1) break;
        if (cargoUsed(state) >= cargoCapacity(state)) break;
        state.cargo[l.id]++;
        budget -= l.value;
    }
}

// ---------- grail, hunger, healing (morning) ----------

function morning(state) {
    const r = actualReach(state, state.reach);

    if (state.enslaved) {
        const lux = randoWeighted(LUXURIES);
        log(state, `The stone fires. Your masters empty your grail: ${lux.name.toLowerCase()} they will never share.`);
        return; // fed by masters; nothing kept
    }

    const stoneAlive = r.polity || !r.deadStone;
    if (stoneAlive) {
        const rolls = hasBoon(state, 'twiceblessed') ? 2 : 1;
        const got = [];
        for (let k = 0; k < rolls; k++) {
            const lux = randoWeighted(LUXURIES);
            if (cargoUsed(state) < cargoCapacity(state)) {
                state.cargo[lux.id]++;
                got.push(lux.name.toLowerCase());
            } else {
                log(state, `Your grail overflows — you leave ${lux.name.toLowerCase()} on the stone.`);
            }
        }
        if (got.length) log(state, `The grailstone fires: bread, fish, and ${got.join(' and ')}.`);
    } else {
        // dead stone: eat from stores or starve
        if (state.cargo.food > 0) {
            state.cargo.food--;
            log(state, `The stone here is dead. You eat from your stores (${state.cargo.food} left).`);
        } else {
            state.hp--;
            log(state, `The stone is dead and the stores are empty. Hunger takes its toll (HP ${state.hp}).`);
            if (state.hp <= 0) { translate(state, 'starved in a dead reach'); return; }
        }
    }

    // angler forages the wilds
    if (!r.polity && hasAbility(state, 'angler') && cargoUsed(state) < cargoCapacity(state)) {
        state.cargo.food++;
    }

    // healer: +1 HP every second day
    if (hasAbility(state, 'healer') && state.day % 2 === 0 && state.hp < MAX_HP) {
        state.hp++;
        log(state, `Your healer tends your wounds (HP ${state.hp}).`);
    }
}

// ---------- world drift (evening) ----------

function worldDrift(state) {
    for (const key of Object.keys(state.chart)) {
        const i = Number(key);
        if (!state.chart[i].polity) continue;
        const base = generateReach(state.seed, i);
        if (!base.polity) continue;
        if (state.riverMut[i] && state.riverMut[i].fallen) continue;
        if (rando() < 0.002) {
            if (rando() < 0.35) {
                state.riverMut[i] = { fallen: true };
            } else {
                const t = randoPick(['open', 'wary', 'hostile']);
                state.riverMut[i] = { temper: t };
            }
        }
    }
    for (const key of Object.keys(state.demand)) {
        state.demand[key] = Math.min(1.0, state.demand[key] + 0.05);
    }
}

// ---------- death and translation ----------

function translate(state, cause) {
    state.deaths++;
    journal(state, `Died: ${cause}. (death #${state.deaths})`);

    // crew are translated too — into the River, not oblivion
    for (const c of state.crew) state.lostSouls.push(c);
    state.crew = [];

    const keepFood = hasBoon(state, 'compartment') ? Math.min(5, state.cargo.food) : 0;
    let keepLux = [];
    if (hasBoon(state, 'compartment')) {
        const order = LUXURIES.slice().sort((a, b) => b.value - a.value);
        for (const l of order) {
            let q = state.cargo[l.id];
            while (q-- > 0 && keepLux.length < 3) keepLux.push(l.id);
        }
    }
    for (const k of Object.keys(state.cargo)) state.cargo[k] = 0;
    state.cargo.food = keepFood;
    for (const id of keepLux) state.cargo[id]++;

    state.boat = { tier: 0, hurt: false };
    state.enslaved = null;
    state.pendingEvent = null;
    state.hp = MAX_HP;
    state.justTranslated = true; // the rest of this day belongs to the shock

    const lo = hasBoon(state, 'strangersmark') ? Math.ceil(state.furthest / 2) : 0;
    state.reach = randoInt(lo, Math.max(lo, state.furthest));
    chartReach(state, state.reach);

    log(state, `— DEATH: ${cause}. —`);
    log(state, `You wake naked on a strange bank, grail in hand. This is reach ${state.reach}. Everything you knew, you still know.`);
}

// ---------- fights ----------

// Returns true if still alive/afloat enough to continue the day.
function resolveFight(state, enemyForce, enemyName, penalty) {
    const mine = playerForce(state) - (penalty || 0) + randoInt(1, 6);
    const theirs = enemyForce + randoInt(1, 6);
    const margin = mine - theirs;
    if (margin >= 0) {
        const loot = Math.max(1, Math.round(enemyForce * 0.8));
        gainLuxuries(state, loot);
        log(state, `You beat off the ${enemyName} and pick over what they dropped (~${loot} value).`);
        // sometimes a freed captive asks to join
        if (rando() < 0.2 && state.recruitPool.length && state.crew.length < crewCapacity(state)) {
            const idx = Math.floor(rando() * state.recruitPool.length);
            const c = state.recruitPool.splice(idx, 1)[0];
            state.crew.push(c);
            log(state, `A freed captive joins you: ${c.name} (${ABILITIES[c.ability].name}).`);
        }
        return true;
    }
    state.hp--;
    loseValue(state, Math.ceil(purseValue(state) / 2));
    log(state, `The ${enemyName} maul you — half your goods gone, and blood in the water (HP ${state.hp}).`);
    if (margin <= -4 && state.boat.tier > 0) {
        state.boat = { tier: 0, hurt: false };
        for (const k of Object.keys(state.cargo)) state.cargo[k] = 0; // the hold goes with the hull
        if (state.crew.length) {
            const names = state.crew.map(c => c.name).join(', ');
            for (const c of state.crew) state.lostSouls.push(c);
            state.crew = [];
            log(state, `They take the boat itself, hold and all. The crew scatters into the water and the crowds — ${names}, gone. The River gives people back, in time.`);
        } else {
            log(state, `They take the boat itself, hold and all. You swim ashore with your grail.`);
        }
    }
    if (state.hp <= 0) translate(state, `killed by ${enemyName}`);
    return state.hp > 0;
}

// ---------- events ----------
// Registry: build(state, params) -> {text, choices:[{label, detail}]}
//           resolve(state, params, idx)

const EVENTS = {
    pirates: {
        build(state, p) {
            const bribe = Math.ceil(purseValue(state) * (hasAbility(state, 'orator') ? 0.225 : 0.3));
            return {
                text: `Pirates! A ${p.boatName} bears down on you, crew howling. Their force looks about ${p.force}; yours is ${playerForce(state)}.`,
                choices: [
                    { label: 'Fight', detail: `force ${playerForce(state)} + d6 vs ${p.force} + d6` },
                    { label: 'Flee', detail: `speed contest — your ${effSpeedUp(state)} vs their oars` },
                    { label: `Bribe (${bribe} value)`, detail: 'they take the toll of the water', disabled: purseValue(state) < Math.max(2, bribe) },
                ],
            };
        },
        resolve(state, p, idx) {
            if (idx === 0) resolveFight(state, p.force, 'pirates', 0);
            else if (idx === 1) {
                const mine = effSpeedUp(state) + randoInt(1, 6);
                const theirs = 2 + zoneIndexOf(state.reach) + randoInt(1, 6);
                if (mine >= theirs) log(state, 'You show them your wake. The howling fades astern.');
                else {
                    log(state, 'They run you down — no escaping this fight, and you start it winded.');
                    resolveFight(state, p.force, 'pirates', 1);
                }
            } else {
                const bribe = Math.ceil(purseValue(state) * (hasAbility(state, 'orator') ? 0.225 : 0.3));
                loseValue(state, bribe);
                log(state, `You heave goods across the water. The pirates salute — professionals — and sheer off.`);
            }
        },
    },

    toll: {
        build(state, p) {
            return {
                text: `${p.name} bars the river with war canoes. "The ${p.temper === 'hostile' ? 'lords' : 'wardens'} of ${p.name} ask a toll of ${p.toll} value."`,
                choices: [
                    { label: `Pay the toll (${p.toll})`, detail: 'and pass in peace', disabled: localPurse(state, state.reach) < p.toll },
                    { label: 'Run the blockade', detail: `speed contest; failure means a fight, winded` },
                    { label: 'Fight', detail: `force ${playerForce(state)} + d6 vs ${p.force} + d6` },
                ],
            };
        },
        resolve(state, p, idx) {
            if (idx === 0) {
                spendValue(state, state.reach, p.toll);
                log(state, `You pay ${p.name}'s toll. The canoes part.`);
            } else if (idx === 1) {
                const mine = effSpeedUp(state) + randoInt(1, 6);
                const theirs = 3 + randoInt(1, 6);
                if (mine >= theirs) log(state, `You run the blockade of ${p.name} — arrows fall short astern.`);
                else resolveFight(state, p.force, `warriors of ${p.name}`, 1);
            } else {
                resolveFight(state, p.force, `warriors of ${p.name}`, 0);
            }
        },
    },

    riverdragon: {
        build(state, p) {
            const choices = [
                { label: 'Fight it', detail: `force ${playerForce(state)} + d6 vs ${p.force} + d6 — win and it feeds the crew for weeks` },
                { label: 'Pull for the bank', detail: 'live to tell it bigger than it was' },
            ];
            if (hasAbility(state, 'angler')) {
                choices.push({ label: 'Let the angler play it', detail: 'like a trout, on a hand line. Madness. It works.' });
            }
            return { text: 'The water humps up beneath you — a riverdragon, thirty feet of appetite.', choices };
        },
        resolve(state, p, idx) {
            if (idx === 0) {
                const mine = playerForce(state) + randoInt(1, 6);
                if (mine >= p.force + randoInt(1, 6)) {
                    const gain = Math.min(12, cargoCapacity(state) - cargoUsed(state));
                    state.cargo.food += Math.max(0, gain);
                    log(state, `The riverdragon dies hard. You render it into ${gain} stores of dried meat.`);
                } else {
                    state.hp--;
                    state.boat.hurt = state.boat.tier > 0;
                    log(state, `It shrugs your steel aside and swats the hull (HP ${state.hp}${state.boat.hurt ? ', boat damaged' : ''}).`);
                    if (state.hp <= 0) translate(state, 'eaten by a riverdragon');
                }
            } else if (idx === 1) {
                if (rando() < 0.2) {
                    state.hp--;
                    log(state, `Its tail clips you as you flee (HP ${state.hp}).`);
                    if (state.hp <= 0) translate(state, 'swatted by a riverdragon');
                } else log(state, 'You give the riverdragon the whole river. It takes it.');
            } else {
                const angler = state.crew.find(c => c.ability === 'angler');
                const gain = Math.min(12, cargoCapacity(state) - cargoUsed(state));
                state.cargo.food += Math.max(0, gain);
                log(state, `${angler.name} plays it for three hours and lands it, grinning. ${gain} stores of meat, and a story no one will believe.`);
            }
        },
    },

    thief: {
        build() { return null; }, // immediate — no choices
        resolve() {},
        immediate(state) {
            if (hasAbility(state, 'watchman')) {
                const w = state.crew.find(c => c.ability === 'watchman');
                log(state, `A grail-thief creeps into camp; ${w.name} was awake. The thief flees empty-handed.`);
                return;
            }
            const order = LUXURIES.slice().sort((a, b) => b.value - a.value);
            const target = order.find(l => state.cargo[l.id] > 0);
            if (target) {
                state.cargo[target.id]--;
                log(state, `A thief in the night. Your ${target.name.toLowerCase()} is gone by morning.`);
            }
        },
    },

    raid: {
        build(state, p) {
            return {
                text: `Grail-raiders hit your camp in the dark — word of your wealth travels faster than you do. Their force is about ${p.force}.`,
                choices: [
                    { label: 'Stand and fight', detail: `force ${playerForce(state)} + d6 vs ${p.force} + d6` },
                    { label: 'Scatter and let them take it', detail: 'lose half your goods, keep your blood' },
                ],
            };
        },
        resolve(state, p, idx) {
            if (idx === 0) resolveFight(state, p.force, 'grail-raiders', 0);
            else {
                loseValue(state, Math.ceil(purseValue(state) / 2));
                log(state, 'You melt into the dark and count what they left. Half, roughly.');
            }
        },
    },

    pressgang: {
        build(state, p) {
            return {
                text: `${p.name}'s grail-slavers close in on the dock, clubs swinging low and friendly. You've seen this before.`,
                choices: [
                    { label: 'Fight clear', detail: `force ${playerForce(state)} + d6 vs ${p.force} + d6 — lose, and it's the chains` },
                    { label: 'Go quietly', detail: 'the chains, but no blood' },
                ],
            };
        },
        resolve(state, p, idx) {
            if (idx === 0) {
                const mine = playerForce(state) + randoInt(1, 6);
                if (mine >= p.force + randoInt(1, 6)) {
                    log(state, `You fight clear of ${p.name}'s slavers and cast off under a rain of curses.`);
                } else {
                    state.hp--;
                    if (state.hp <= 0) { translate(state, `killed resisting the slavers of ${p.name}`); return; }
                    enslave(state, p.name);
                }
            } else enslave(state, p.name);
        },
    },

    drifter: {
        build() { return null; },
        resolve() {},
        immediate(state) {
            // Reunion first: the River gives people back.
            if (state.lostSouls.length && rando() < 0.6) {
                const idx = Math.floor(rando() * state.lostSouls.length);
                const c = state.lostSouls.splice(idx, 1)[0];
                if (state.crew.length < crewCapacity(state)) {
                    state.crew.push(c);
                    journal(state, `Reunion: ${c.name}, found again.`);
                    log(state, `A familiar face on the bank — ${c.name}! Translated downriver, walking ever since. They step aboard like they never left.`);
                } else {
                    state.recruitPool.push(c);
                    log(state, `${c.name} hails you from the bank — alive again! No berth aboard; they'll wait at the next town, they say.`);
                }
                return;
            }
            if (state.recruitPool.length && state.crew.length < crewCapacity(state) && rando() < 0.5) {
                const idx = Math.floor(rando() * state.recruitPool.length);
                const c = state.recruitPool.splice(idx, 1)[0];
                state.crew.push(c);
                log(state, `You pull a half-drowned stranger from the current: ${c.name} (${ABILITIES[c.ability].name}). They owe you, and they know it.`);
                return;
            }
            state.cargo.food = Math.min(cargoCapacity(state) - cargoUsed(state) + state.cargo.food, state.cargo.food + 2);
            log(state, 'A derelict raft drifts by — nobody aboard, two stores of dried fish. The River provides.');
        },
    },

    storm: {
        build() { return null; },
        resolve() {},
        immediate(state) {
            if (state.boat.tier === 0) { log(state, 'A line-squall lashes the valley. You shelter under the grass and wait it out.'); return; }
            if (hasAbility(state, 'boatwright') || state.boat.tier >= 4) {
                log(state, 'A squall tears down the valley; good bones and good hands see the boat through.');
                return;
            }
            state.boat.hurt = true;
            log(state, 'A squall drives you onto the shallows — the boat is damaged (speed 1 until repaired).');
        },
    },

    stranger: {
        build() { return null; },
        resolve() {},
        immediate(state) {
            let i = state.reach + 1, added = 0;
            while (added < 10) {
                if (!isCharted(state, i)) { chartReach(state, i); added++; }
                i++;
                if (i > state.reach + 60) break;
            }
            journal(state, 'The Mysterious Stranger came by night.');
            log(state, `A stranger shares your fire, and is gone before dawn. You find you know the next ten reaches as if you'd walked them. "It is further than you think," says a voice in your memory, "and worth more."`);
        },
    },
};

function enslave(state, polityName) {
    // boat, cargo, crew — taken. The grail they cannot open; you they can keep.
    for (const c of state.crew) state.lostSouls.push(c);
    state.crew = [];
    for (const k of Object.keys(state.cargo)) state.cargo[k] = 0;
    state.boat = { tier: 0, hurt: false };
    state.enslaved = { plots: 0 };
    journal(state, `Enslaved at ${polityName}.`);
    log(state, `Clubbed down and chained. You are a grail-slave of ${polityName} now — fed enough to live, kept for what your grail yields.`);
}

// ---------- evening event roll ----------

function eveningEvent(state, context) {
    if (state.pendingEvent || state.enslaved || state.hp <= 0) return;
    const r = actualReach(state, state.reach);
    const zi = zoneIndexOf(state.reach);
    const zone = ZONES[zi];
    const h = heat(state);
    const traveled = context === 'travel';

    const options = [{ id: null, w: 8 }];

    if (traveled) {
        options.push({ id: 'pirates', w: 1 + h * 0.5 + zi * 0.3 });
        options.push({ id: 'storm', w: 0.8 + zi * 0.2 });
        if (!r.polity) options.push({ id: 'riverdragon', w: 0.4 + zi * 0.1 });
        options.push({ id: 'drifter', w: 0.7 + state.lostSouls.length * 0.3 });
    } else {
        options.push({ id: 'drifter', w: 0.3 + state.lostSouls.length * 0.3 });
    }
    if (purseValue(state) > 0) {
        const thiefW = r.polity ? ECONOMIES[r.polity.economy].thiefW * 0.4 : 0.4;
        options.push({ id: 'thief', w: thiefW });
    }
    if (h >= 4) options.push({ id: 'raid', w: (h - 3) * 0.3 });
    if (!traveled && r.polity && ECONOMIES[r.polity.economy].pressgang) {
        const press = TEMPERS[r.polity.temper].pressMult;
        const scared = playerForce(state) >= zone.pirateForce ? 0.3 : 1.0;
        options.push({ id: 'pressgang', w: 1.2 * press * scared });
    }
    options.push({ id: 'stranger', w: 0.15 });

    const picked = randoWeighted(options);
    if (!picked.id) return;

    const ev = EVENTS[picked.id];
    let params = {};
    if (picked.id === 'pirates') params = { force: zone.pirateForce + randoInt(-2, 2), boatName: randoPick(['war canoe', 'black-sailed cutter', 'swarm of dugouts', 'lean galley']) };
    if (picked.id === 'riverdragon') params = { force: zone.pirateForce + 2 };
    if (picked.id === 'raid') params = { force: zone.pirateForce + randoInt(-1, 3) };
    if (picked.id === 'pressgang') params = { name: r.polity.name, force: zone.pirateForce + 2 };

    if (ev.immediate) { ev.immediate(state); return; }
    state.pendingEvent = { id: picked.id, params };
}

// ---------- the day wrapper ----------

function advanceDay(state, actionFn, eventContext) {
    if (state.pendingEvent || state.pendingBoon) return false;
    state.justTranslated = false;
    morning(state);
    // dying in the morning (starvation -> translation) forfeits the day:
    // you do not wake on a strange bank and then calmly sail upriver.
    if (!state.justTranslated) actionFn();
    if (!state.justTranslated) eveningEvent(state, eventContext);
    worldDrift(state);
    state.day++;
    saveState(state);
    return true;
}

// ---------- travel ----------

function stepInto(state, i) {
    // chart (with staleness surprise), milestones, toll interception
    state.reach = i;
    if (chartStale(state, i)) {
        log(state, `The banks at reach ${i} do not match your chart — war has been here since you last passed.`);
    }
    chartReach(state, i);
    if (hasBoon(state, 'riversense')) {
        for (let k = 1; k <= 3; k++) if (!isCharted(state, i + k)) chartReach(state, i + k);
    }
    if (i > state.furthest) state.furthest = i;

    const r = actualReach(state, i);
    if (r.milestone && !state.milestonesSeen.includes(i)) {
        state.milestonesSeen.push(i);
        offerBoon(state, i);
    }
    if (r.polity) {
        const econ = ECONOMIES[r.polity.economy];
        const tollChance = (econ.tolls ? 0.5 : 0) + TEMPERS[r.polity.temper].tollW * 0.15;
        if (rando() < Math.min(0.8, tollChance)) {
            const zi = zoneIndexOf(i);
            state.pendingEvent = {
                id: 'toll',
                params: { name: r.polity.name, temper: r.polity.temper, toll: 3 + zi * 2, force: ZONES[zi].pirateForce },
            };
            return false; // movement stops here
        }
    }
    return true;
}

function actTravel(state, dir) {
    if (state.enslaved) return false;
    return advanceDay(state, () => {
        const dist = dir > 0 ? effSpeedUp(state) : Math.min(state.reach, effSpeedDown(state));
        let moved = 0;
        for (let s = 0; s < dist; s++) {
            const next = state.reach + dir;
            if (next < 0) break;
            moved++;
            if (!stepInto(state, next)) break;
        }
        if (moved > 0) log(state, `You make ${moved} reach${moved > 1 ? 'es' : ''} ${dir > 0 ? 'upriver against the current' : 'downriver with the current'}. This is reach ${state.reach}.`);
        else log(state, 'You make no distance today.');
    }, 'travel');
}

// ---------- camp / port actions (1 day each) ----------

function actRest(state) {
    return advanceDay(state, () => {
        const r = actualReach(state, state.reach);
        const fed = r.polity || !r.deadStone || state.cargo.food > 0;
        if (fed && state.hp < MAX_HP) {
            state.hp++;
            log(state, `A day of rest. Wounds knit (HP ${state.hp}).`);
        } else {
            log(state, 'A quiet day on the bank. The River rolls by, unimpressed.');
        }
    }, 'camp');
}

function actBuildRaft(state) {
    if (state.boat.tier !== 0 || state.enslaved) return false;
    return advanceDay(state, () => {
        state.boat = { tier: 1, hurt: false };
        log(state, 'A day of lashing bamboo and grass-rope: you have a raft. The River is yours — slowly.');
    }, 'camp');
}

// Repair is always free and always a day — a broke sailor with a cracked hull
// must never be *stuck*, just slow. (Boatwrights prevent the damage instead.)
function actRepair(state) {
    if (!state.boat.hurt || state.enslaved) return false;
    return advanceDay(state, () => {
        state.boat.hurt = false;
        log(state, 'A day of patching and caulking. The boat is sound.');
    }, 'camp');
}

function actBuyBoat(state, tier) {
    const r = actualReach(state, state.reach);
    if (!r.polity || r.polity.economy !== 'builder') return false;
    if (tier <= state.boat.tier) return false;
    const cost = BOATS[tier].price * TEMPERS[r.polity.temper].priceMult * (speaks(state, r) ? 0.75 : 1);
    if (localPurse(state, state.reach) < cost) return false;
    return advanceDay(state, () => {
        spendValue(state, state.reach, cost);
        noteDemand(state, state.reach, cost);
        const old = BOATS[state.boat.tier].name;
        state.boat = { tier, hurt: false };
        log(state, `The yards of ${r.polity.name} deliver: a ${BOATS[tier].name}. The old ${old.toLowerCase()} goes to a family of twelve.`);
    }, 'camp');
}

function actBuyFood(state, qty) {
    const r = actualReach(state, state.reach);
    if (!r.polity) return false;
    const unit = buyPrice(state, state.reach, 'food');
    const cost = unit * qty;
    if (localPurse(state, state.reach) < cost) return false;
    if (cargoUsed(state) + qty > cargoCapacity(state)) return false;
    spendValue(state, state.reach, cost);
    noteDemand(state, state.reach, cost);
    state.cargo.food += qty;
    log(state, `You trade for ${qty} stores of dried fish and acorn bread.`);
    saveState(state);
    return true; // trade is instant — no day passes
}

function actBuyWeapons(state, qty) {
    const r = actualReach(state, state.reach);
    if (!r.polity || ECONOMIES[r.polity.economy].buys.weapons === undefined) return false;
    const unit = buyPrice(state, state.reach, 'weapons');
    const cost = unit * qty;
    if (localPurse(state, state.reach) < cost) return false;
    if (cargoUsed(state) + qty > cargoCapacity(state)) return false;
    spendValue(state, state.reach, cost);
    noteDemand(state, state.reach, cost);
    state.cargo.weapons += qty;
    log(state, `You trade for ${qty} flint-edged weapons.`);
    saveState(state);
    return true;
}

// NOTE: there is deliberately no actSell. Barter has no coin — luxuries
// convert to goods only at the moment of purchase (spendValue at local rates).
// The "purse" is just your goods valued at this port's prices.

function actBuyRumor(state) {
    const r = actualReach(state, state.reach);
    if (!r.polity || ECONOMIES[r.polity.economy].buys.rumor === undefined) return false;
    const cost = buyPrice(state, state.reach, 'rumor');
    if (localPurse(state, state.reach) < cost) return false;
    return advanceDay(state, () => {
        spendValue(state, state.reach, cost);
        noteDemand(state, state.reach, cost);
        let i = state.reach + 1, added = 0;
        while (added < RUMOR_RANGE && i < state.reach + 100) {
            if (!isCharted(state, i)) { chartReach(state, i); added++; }
            i++;
        }
        log(state, `A day in the drinking halls of ${r.polity.name}. Sailors' talk charts ${added} reaches upriver.`);
    }, 'camp');
}

function actLearnLanguage(state) {
    const r = actualReach(state, state.reach);
    if (!r.polity) return false;
    if (state.languages.includes(r.polity.lang)) return false;
    const cost = buyPrice(state, state.reach, 'language');
    if (localPurse(state, state.reach) < cost) return false;
    if (state.pendingEvent || state.pendingBoon) return false;
    spendValue(state, state.reach, cost);
    noteDemand(state, state.reach, cost);
    const days = hasAbility(state, 'linguist') ? 1 : 3;
    // a study montage: grail fires, no events — you're a guest indoors
    state.justTranslated = false;
    for (let d = 0; d < days; d++) {
        morning(state);
        if (state.justTranslated) { saveState(state); return true; } // lessons cut brutally short
        worldDrift(state);
        state.day++;
    }
    state.languages.push(r.polity.lang);
    const fam = LANG_FAMILIES.find(f => f.id === r.polity.lang);
    log(state, `${days} day${days > 1 ? 's' : ''} of lessons: you now speak ${fam.name}, tongue of ${r.polity.name} and its kin.`);
    saveState(state);
    return true;
}

function actHeal(state) {
    const r = actualReach(state, state.reach);
    if (!r.polity || ECONOMIES[r.polity.economy].buys.heal === undefined) return false;
    if (state.hp >= MAX_HP) return false;
    const cost = buyPrice(state, state.reach, 'heal') * (MAX_HP - state.hp);
    if (localPurse(state, state.reach) < cost) return false;
    return advanceDay(state, () => {
        spendValue(state, state.reach, cost);
        noteDemand(state, state.reach, cost);
        state.hp = MAX_HP;
        log(state, `The healers of ${r.polity.name} take their fee and their time. You leave whole.`);
    }, 'camp');
}

// Deterministic per (reach, day): who's on the dock today?
function getDockOffer(state) {
    const r = actualReach(state, state.reach);
    if (!r.polity || !state.recruitPool.length) return null;
    if (state.crew.length >= crewCapacity(state)) return null;
    const econ = ECONOMIES[r.polity.economy];
    const roll = hashRand(state.seed, state.reach * 131 + state.day, 'offer');
    if (roll > econ.recruitW * 0.18 + (speaks(state, r) ? 0.1 : 0)) return null;
    const idx = Math.floor(hashRand(state.seed, state.reach * 131 + state.day, 'who') * state.recruitPool.length);
    return { idx, crew: state.recruitPool[idx] };
}

function actRecruit(state) {
    const offer = getDockOffer(state);
    if (!offer) return false;
    const cost = buyPrice(state, state.reach, 'recruit');
    if (localPurse(state, state.reach) < cost) return false;
    return advanceDay(state, () => {
        spendValue(state, state.reach, cost);
        noteDemand(state, state.reach, cost);
        const c = state.recruitPool.splice(offer.idx, 1)[0];
        state.crew.push(c);
        log(state, `${c.name} signs aboard for a hiring gift (${ABILITIES[c.ability].name}: ${ABILITIES[c.ability].desc}).`);
    }, 'camp');
}

// ---------- slavery ----------

function actToil(state) {
    if (!state.enslaved) return false;
    return advanceDay(state, () => {
        log(state, 'You toil at the fish-weirs and keep your head down.');
    }, 'camp');
}

function actPlot(state) {
    if (!state.enslaved) return false;
    return advanceDay(state, () => {
        state.enslaved.plots++;
        let chance = 0.20 + 0.05 * (state.enslaved.plots - 1);
        if (state.lostSouls.some(c => c.ability === 'liberator')) chance += 0.25;
        if (rando() < chance) {
            state.enslaved = null;
            state.reach = Math.max(0, state.reach - 1);
            chartReach(state, state.reach);
            journal(state, 'Escaped slavery.');
            const lib = state.lostSouls.find(c => c.ability === 'liberator');
            log(state, lib
                ? `A whisper in the dark — ${lib.name} came back for you. You go over the palisade and downriver before dawn. Free, afoot, alive.`
                : 'The night watch dozes. You go over the palisade and downriver before dawn. Free, afoot, alive.');
        } else if (rando() < 0.20) {
            state.hp--;
            log(state, `Caught testing the palisade. Beaten (HP ${state.hp}).`);
            if (state.hp <= 0) translate(state, 'beaten to death by slavers');
        } else {
            log(state, 'You map the guard rotations and say nothing. Soon.');
        }
    }, 'camp');
}

function actSuicide(state) {
    if (state.pendingEvent || state.pendingBoon) return false;
    journal(state, 'Took the Suicide Express.');
    log(state, 'There is always one door out. You take it.');
    translate(state, 'the Suicide Express');
    state.day++;
    saveState(state);
    return true;
}

// ---------- events & boons: UI hooks ----------

function describePendingEvent(state) {
    if (!state.pendingEvent) return null;
    const ev = EVENTS[state.pendingEvent.id];
    return ev.build(state, state.pendingEvent.params);
}

function resolvePendingEvent(state, choiceIdx) {
    if (!state.pendingEvent) return;
    const ev = EVENTS[state.pendingEvent.id];
    const params = state.pendingEvent.params;
    state.pendingEvent = null;
    ev.resolve(state, params, choiceIdx);
    saveState(state);
}

function offerBoon(state, reachIndex) {
    const unowned = BOON_IDS.filter(b => !state.boons.includes(b));
    if (!unowned.length) return;
    const a = Math.floor(hashRand(state.seed, reachIndex, 'boonA') * unowned.length);
    let b = Math.floor(hashRand(state.seed, reachIndex, 'boonB') * unowned.length);
    if (unowned.length > 1 && b === a) b = (b + 1) % unowned.length;
    state.pendingBoon = unowned.length > 1 ? [unowned[a], unowned[b]] : [unowned[a]];
}

function chooseBoon(state, boonId) {
    if (!state.pendingBoon || !state.pendingBoon.includes(boonId)) return;
    state.boons.push(boonId);
    state.pendingBoon = null;
    journal(state, `The Stranger's gift: ${BOONS[boonId].name}.`);
    log(state, `By night, a Stranger. By morning, a gift that death cannot take: ${BOONS[boonId].name}.`);
    saveState(state);
}
