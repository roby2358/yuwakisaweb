// index.js — bootstrap: resume the saved life or wake a new one.

(function () {
    let state = loadState();
    if (state) {
        document.getElementById('intro-panel').classList.add('hidden');
    } else {
        state = newState(Math.floor(Math.random() * 0xffffffff));
        chartReach(state, 0);
        log(state, 'You wake on the bank, hairless and young, a grail chained to your wrist. Upriver the water goes on forever.');
        saveState(state);
    }
    uiInit(state);
})();
