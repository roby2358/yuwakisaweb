# Riverworld — Game Dynamics

*After Philip José Farmer. Everyone who ever died wakes on the banks of a River that
never ends. You cannot die — not permanently. But everything you build can.*

## Theme

**You have infinite lives but only one story: the pull of the upriver truth against the
comfort of what you've built.** Death is never game over — it is translation: you wake
naked on a strange bank, holding nothing but your grail and everything you *know*. The
fun is the long climb upriver toward the source, losing boats, crews, and fortunes along
the way, and rebuilding faster each time because the River is the same river and you
have charted it. There is no end and no fail state — only distance, knowledge, and the
people you find again.

## Key Drivers

1. **Accumulation and Windfall** — two ladders that death treats differently. *Material*
   (boat, crew, cargo) resets on death; *knowledge* (the chart, languages, milestone
   boons) never does. Every run rebuilds material faster because knowledge compounded.
   Windfalls: a translation that lands you *ahead*, a lost crewmate found on a dock, a
   riverdragon's worth of meat.
2. **Loss Aversion Over Reward-Seeking** — the player is immortal; nothing else is. The
   boat can be stolen, the crew scattered, the cargo taken by slavers. The game's sting
   is never "you lose" — it is "you lost *that*."
3. **Variable Reinforcement on a Competence Backbone** — the grail fires every day with
   a random luxury; events roll every travel day; translation is a dice throw across the
   whole known river. But provisioning, chart knowledge, and force math are real
   decisions that shape every roll's stakes.

Source-material mapping (dynamics, not scenes): resurrection → soft-reset roguelite
death; grailstones → daily variable-reward drip that doubles as travel fuel logistics;
grail-slaver states → the economy's predators; the Suicide Express → death as a
*deliberate tool*; Burton's endless journey → the distance ladder; "everyone who ever
lived is here" → a recruitable roster of the historical dead, who when lost are not
gone, merely *somewhere on the River*.

## The Core Loop

Travel upriver → the grail fires daily (food + a random luxury) → luxuries buy boats,
crew, rumors, and passage at bank polities → a better boat goes faster and carries more
but is *coveted* → pirates, slavers, storms, and dead stretches take their toll → death
translates you to a random point on the known river, stripped of everything material →
the chart, your languages, and your boons remain → rebuild in half the time, push
further.

The double edge that holds it together: **everything that makes you faster makes you a
target, and the only thing that's safe is the one thing that can't be taken — what you
know.**

## The River

*Serves: accumulation (the chart is the persistent progress bar), readable consequences
(a charted reach is a known quantity).*

- The River is a 1-D sequence of **reaches** (index 0, 1, 2, …), procedurally generated
  from the game seed — deterministic, so knowledge is real. Effectively infinite.
- Each reach is either **wilds** or holds a **bank polity**. Wilds reaches may have a
  **dead grailstone** (no food fires there).
- **Zones** carve the river into escalating bands (boundaries at reach 30 / 80 / 150 /
  240 / 350, last band extends forever): upriver means stronger current, more dead
  stones, fewer and harsher polities, stronger pirates. Escalation is tied to the
  player's own progress upriver, not to time.
- **The chart**: visiting a reach snapshots it into `state.chart`. The chart survives
  death. But the River drifts — wars flip tempers, polities fall, new ones rise. Arriving
  somewhere that no longer matches your chart is an event, not a bug: *the chart is
  memory, and memory ages.*

```
generateReach(seed, i):            # pure function of (seed, i)
    zone = zoneOf(i)
    if hash(seed,i,'polity') < zone.polityChance: reach has polity
        polity = { name, economy, temper, langFamily } from hashed rolls
    else wilds; deadStone if hash(seed,i,'stone') < zone.deadStoneChance
mutations stored in state.riverMut[i] overlay the generated base
```

## The Day

One turn = one day. Every day, in order:

1. **Grail fires** (if the reach's stone lives): +1 food eaten automatically, +1 random
   luxury (cigars / liquor / cloth / dreamgum / a rare lighter). If enslaved, your
   masters take the luxury — that is *why* they keep you.
2. **Player action** — travel upriver (boat speed − zone current, min 1 reach) or
   downriver (speed + current + 1: retreat is always cheap — gut check: the current is
   your enemy going up and your friend going down), or one port/camp action.
3. **Event roll** — weighted by zone, reach type, and your **heat** (see Covetousness).
4. **World drift** — small chance a known polity mutates; port demand recovers; autosave.

In a dead-stone reach the grail stays silent: **−1 food from stores**, and at 0 stores,
−1 HP per hungry day. Upriver zones have long dead stretches — expeditions must be
provisioned. *Serves: scarcity of agency (cargo space vs. food vs. trade goods is the
packing problem every departure).*

## Grail and Luxuries

*Serves: variable reinforcement (the daily roll), low-probability hope (the lighter).*

The grail is the one possession that cannot be taken — it opens for no one else. Daily
luxury roll: cigars 30% (value 1), liquor 25% (2), cloth 25% (2), dreamgum 15% (3),
lighter 5% (8). Luxuries are the *only* currency; your **purse** is their total barter
value at local multipliers. Theocracies ban dreamgum (confiscate on docking, or pay
triple to the discreet); slaver ports pay best for everything and ask no questions.

## Bank Polities

*Serves: readable consequences (economy and temper are visible on the chart and imply
the risk/price table), asymmetry (one docking mechanic, five meanings).*

One template, two axes — **economy** × **temper** (open / wary / hostile):

| Economy | Offers | Edge |
|---|---|---|
| Trade hub | cheap food & weapons, rumors, recruits | crowded: thieves |
| Builder | boat purchases & repairs, pays 2× for cloth | prices high |
| Theocracy | healing, cheap language lessons, no press-gangs | dreamgum banned |
| Warlord | cheap weapons, fighter recruits | tolls on passing |
| Slaver | best sell prices, black-market everything | press-gang risk |

Port actions (1 day each): trade, recruit, buy rumor (+charts N reaches ahead — rumor
range is the information-as-currency purchase), language lesson, buy/repair boat, rest.
Hostile reaches may demand a **toll** just to pass — pay, outrun, or fight.

**Demand decay**: each sale reduces local demand (floor 0.4), recovering +0.05/day.
Farming one port strangles itself. *Serves: escalating commitment (anti-turtle, baked
into the price system, not bolted on).*

## Boats

*Serves: accumulation (the material ladder), double-edged mechanics (covetousness).*

| Tier | Speed | Cargo | Crew | Covet |
|---|---|---|---|---|
| Afoot | 1 | 3 | 1 | 0 |
| Raft (build: 1 day, free) | 1 | 6 | 2 | 0 |
| Dugout | 2 | 10 | 3 | 1 |
| Sail canoe | 3 | 16 | 4 | 2 |
| Cutter | 4 | 26 | 6 | 4 |
| Schooner | 5 | 40 | 9 | 7 |

Effective upriver speed = max(1, speed − zone current) — you always move at least 1
(never let a unit feel stuck), but deep-river current makes small boats *logistically*
non-viable (more hungry days per dead stretch), not forbidden. Storm damage halves you
to speed 1 until a day of repair.

## Covetousness (Heat)

*Serves: double-edged mechanics — the core one.*

`heat = boat.covet + floor(purseValue / 20)`. Heat weights pirate and grail-raid event
odds. A rich schooner is a rolling invitation; a pauper on a raft is invisible. Sitting
in port with a fat purse does not cool you — wealth *is* heat, so the game constantly
whispers: spend it, bank it into the boat, or lose it. There is no safe hoard.

## Crew: The Historical Dead

*Serves: guardianship (named, distinct, mourned), low-probability hope (reunion),
comedy (Izaak Walton out-fishing a riverdragon).*

Everyone who ever died is on the River. Recruits are drawn from a roster of real
historical figures, each one ability from a small template set (passive modifiers only):
fighter +2 force, pilot +1 speed, linguist (lessons in 1 day, trade bonus), quartermaster
+4 cargo, watchman (negates night theft), healer (+1 HP per 2 days), boatwright (storms
don't damage; repairs free), orator (recruit/bribe discount), angler (+1 food/day in
wilds), liberator (+25% escape rolls). Mark Twain is a pilot. Richard Burton is a
linguist. Harriet Tubman is a liberator. Crew slots come from the boat.

**No one is ever gone.** A crewmate lost to pirates, slavers, or your own death is
*translated*, entering `state.lostSouls`. The "familiar face on the dock" event (weight
∝ lost souls count) returns one, free, overjoyed. Grief becomes anticipation — the
Riverworld conceit doing mechanical work.

## Force and Fights

One resolution for every fight: `force = 2 + 2·fighters + min(weapons, crewCount) +
boatForce (+2 Old Soldier boon)`. Contest: `force + d6` vs `theirs + d6`. Win: loot.
Lose: −1 HP and half your purse. Lose by 4+: the boat itself is taken — marooned afoot,
a crew member translated away. Pirates offer fight / flee (speed contest) / bribe (30%
of purse) — always three outs, always priced. *Serves: readable consequences (the odds
are computable before choosing).*

## Slavery

*Serves: loss aversion (the worst non-death outcome), scarcity of agency (three verbs).*

Press-ganged at a slaver port (force check to resist): boat and cargo confiscated, crew
scattered to the lost souls, and each day your grail's luxury goes to the masters. Daily
choice: **toil** (nothing, safe), **plot** (escape roll 20% +5% per consecutive plot,
+25% with liberator memory; failure 20% chance of a beating, −1 HP), or **the Suicide
Express**. Escape puts you afoot, one reach downriver, with your grail and your chart.

## Death and Translation

*Serves: the whole design.* Death — starvation, execution, a lost fight at 0 HP, or
**chosen suicide, any time, one button** — is never game over:

```
onDeath():
    boat, cargo, crew -> gone (crew join lostSouls; world pool)
    keep: chart, languages, boons, journal, furthest, seed
    reach = randInt(0, furthest)            # Stranger's Mark: randInt(furthest/2, furthest)
    wake afoot, 3 HP, empty grail; log the death in the journal
```

The Suicide Express is Farmer's own mechanic: death as desperate fast-travel roulette.
Enslaved with no boat left to lose? The Express is nearly free. Commanding a schooner
with a full crew? Unthinkable. The cost of dying scales with exactly how well you're
doing — loss aversion, self-tuning.

## Milestones: The Ethicals

*Serves: accumulation (permanent, death-proof), windfall, near-miss architecture (dying
20 reaches short of one stings correctly).*

First arrival at each zone boundary (reach 30, 80, 150, 240, 350…), a Stranger finds
your camp by night and offers a **choice of two boons** (permanent, survive death):
Twice-Blessed Grail (2 luxury rolls/day), the Stranger's Mark (translations land in the
upper half), Hidden Compartment (keep 5 food + 3 luxuries through death), Old Soldier's
Memory (+2 force), Gift of Tongues (all language bonuses everywhere), River Sense
(auto-chart 3 reaches ahead). Choosing between two is a real decision; the pair offered
is seeded per milestone.

## Languages

*Serves: information as currency, accumulation (persists through death).*

Six language families, one per polity (seeded). Speaking the local family: +25% sell
prices, −25% buy prices, +recruit chance, tolls halved. Lessons: 3 docked days (1 with
a linguist). The chart records each polity's family — so the chart also tells you where
your tongues are worth money.

## State Model

```
state = {
  seed, day, hp, food,
  reach, furthest, deaths,
  boat:      { tier, hurt },
  cargo:     { food, weapons, cigars, liquor, cloth, dreamgum, lighter },
  crew:      [{ name, ability }],
  lostSouls: [{ name, ability }],
  languages: ["family", ...],
  boons:     ["boonId", ...],
  chart:     { i: { snapshot } },       // survives death
  riverMut:  { i: { mutation } },       // world drift overlay
  demand:    { i: number },             // per-port demand
  enslaved:  null | { reach, plots },
  pendingEvent: null | { id, ... },
  milestonesSeen: [reachIndex, ...],
  journal:   ["...", ...]
}
```

## Strategies

- **Early (afoot at the Delta):** walk, eat from the stone, build a raft, sell the
  grail's drip at the first trade hub. The Delta is gentle — polities open, stones live.
- **The provisioning problem (recurring tension):** every dead stretch is a packing
  decision — cargo spent on food is cargo not earning at the far end; a faster boat
  shortens the stretch but raises the heat. This is the game's every-departure decision.
- **Chart-led rebuilding (the meta-loop):** after translation you are naked but the
  chart shows every builder, hub, and slaver between you and your furthest mark.
  Rebuild time should visibly shrink run over run — that's the competence backbone.
- **Rumor-buying before deep pushes:** charted danger is avoidable danger; a slaver
  reach you know about is a reach you pass at speed without docking. Information
  spent is risk removed.
- **The heat trade-off:** convert purse into boat (heat stays, wealth banked into
  capability) or run rich and fat (fast target). Deliberately traveling poor —
  spending down before departure — is intended play, not an exploit.
- **The Suicide Express gamble:** enslaved far downriver with nothing? Die. Expected
  landing is the middle of your known river, and with the Stranger's Mark the Express
  becomes a genuine (chaotic) travel option. Landing *above* your death point is the
  windfall that gets retold.
- **Reunion runs:** many lost souls = strong dock-event odds; docking often after a
  disaster actively rebuilds the old crew. Losses convert to future hope, mechanically.

### Anti-strategies (and what prevents them)

- **"Farm one friendly port forever"** — demand decay floors sell prices at 40%; heat
  from the growing purse raises raid odds; world drift can flip the port's temper.
  Three mechanical pressures, no advisory ones.
- **"Suicide-spam to fast-travel upriver"** — landing is uniform on [0, furthest]:
  expected value is *backwards* from anywhere past halfway, and every hop burns all
  material progress. It's a gamble priced by your own success.
- **"Never dock, avoid all events"** — dead stretches force provisioning, which forces
  ports; tolls fire on *passing* hostile reaches; pirates strike on the water. There is
  no zero-contact line, only chosen contacts.
- **"Turtle downriver in the easy zones"** — nothing upriver ever comes *at* you (the
  River doesn't chase), but every ladder that makes numbers go up — milestones, boons,
  zones, the furthest mark — lives upstream. The game never punishes rest; it just
  keeps all the fun above you. This is deliberate: it's the recurring-play posture.
  Come back, push a little further.

## Tuning Notes

All first-guess numbers; tune by halve-and-double:

- Luxury weights/values; the 5% lighter is the slot-machine cherry — keep it rare.
- Zone table (polity chance, dead-stone chance, current, pirate force 3/5/8/11/15/20).
- Heat divisor (purse/20) and pirate weight per heat point — sets how heavy success sits.
- Escape base 20% (+5%/plot): expected slavery stay ≈ 4 days; miserable, not endless.
- Demand decay 1%/value, recovery 0.05/day — sets the port-farming half-life.
- Translation range: uniform [0, furthest]. If deaths feel too brutal in play, weight
  toward the upper half globally rather than shrinking the range — variance is the fun.
- Boat prices 8/20/45/90 against a grail drip of ~2 value/day: a dugout is a week of
  patience or one lucky trade; a schooner is an *era*.
