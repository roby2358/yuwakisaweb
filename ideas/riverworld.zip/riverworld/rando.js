// rando.js — seeded randomness.
// Two kinds: a mutable stream (rando) for live play, and a pure hash (hashRand)
// for anything that must be deterministic per (seed, reach) — river generation.

let _randoState = (Math.floor(Math.random() * 0xffffffff)) >>> 0;

function randoSeed(s) { _randoState = s >>> 0; }

// mulberry32 stream
function rando() {
    _randoState = (_randoState + 0x6D2B79F5) >>> 0;
    let t = _randoState;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function randoInt(lo, hi) { // inclusive both ends
    return lo + Math.floor(rando() * (hi - lo + 1));
}

function randoPick(arr) { return arr[Math.floor(rando() * arr.length)]; }

// Weighted pick from [{w: number, ...}, ...]
function randoWeighted(items) {
    let total = 0;
    for (const it of items) total += it.w;
    let roll = rando() * total;
    for (const it of items) {
        roll -= it.w;
        if (roll <= 0) return it;
    }
    return items[items.length - 1];
}

// Pure hash in [0,1) of (seed, index, salt string) — the river's bones.
function hashRand(seed, index, salt) {
    let h = seed >>> 0;
    h = Math.imul(h ^ (index + 0x9E3779B9), 0x85EBCA6B);
    for (let i = 0; i < salt.length; i++) {
        h = Math.imul(h ^ salt.charCodeAt(i), 0xC2B2AE35);
        h = (h << 13) | (h >>> 19);
    }
    h ^= h >>> 16;
    h = Math.imul(h, 0x2C1B3C6D);
    h ^= h >>> 13;
    return (h >>> 0) / 4294967296;
}

function hashPick(seed, index, salt, arr) {
    return arr[Math.floor(hashRand(seed, index, salt) * arr.length)];
}
