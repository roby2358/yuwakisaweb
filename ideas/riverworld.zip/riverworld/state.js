// state.js — the whole game fits in one struct. Saved raw to localStorage.
// No save migration: prototypes break old saves, and that's fine.

const SAVE_KEY = 'riverworld-save';

function newState(seed) {
    return {
        seed: seed >>> 0,
        day: 1,
        hp: MAX_HP,
        reach: 0,
        furthest: 0,
        deaths: 0,
        boat: { tier: 0, hurt: false },
        cargo: { food: 2, weapons: 0, cigars: 0, liquor: 0, cloth: 0, dreamgum: 0, lighter: 0 },
        crew: [],
        lostSouls: [],
        recruitPool: CREW_ROSTER.map(c => ({ ...c })),   // not yet met
        languages: [],
        boons: [],
        chart: {},
        riverMut: {},
        demand: {},          // reach index -> 0.4..1.0
        enslaved: null,      // { plots } while captive
        justTranslated: false, // set by translate(); forfeits the rest of the day
        pendingEvent: null,  // { id, text, choices: [...] } awaiting a decision
        pendingBoon: null,   // [boonId, boonId] awaiting a choice
        milestonesSeen: [],
        journal: [],
        log: [],
    };
}

function saveState(state) {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(state)); } catch (e) { /* headless */ }
}

function loadState() {
    try {
        const raw = localStorage.getItem(SAVE_KEY);
        return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
}

function clearSave() {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* headless */ }
}
