// data.js — content tables. Templates, not snowflakes: every polity is
// economy × temper, every crew member is a name on one of ten abilities,
// every event is a parameter set for the one event template in engine.js.

// ---- Luxuries (the grail's daily roll; the only currency) ----
const LUXURIES = [
    { id: 'cigars',   name: 'Cigars',   w: 30, value: 1 },
    { id: 'liquor',   name: 'Liquor',   w: 25, value: 2 },
    { id: 'cloth',    name: 'Cloth',    w: 25, value: 2 },
    { id: 'dreamgum', name: 'Dreamgum', w: 15, value: 3 },
    { id: 'lighter',  name: 'Lighter',  w: 5,  value: 8 },
];
const LUX_BY_ID = Object.fromEntries(LUXURIES.map(l => [l.id, l]));

// ---- Boats ----
const BOATS = [
    { tier: 0, name: 'Afoot',      speed: 1, cargo: 3,  crew: 1, covet: 0, force: 0, price: 0 },
    { tier: 1, name: 'Raft',       speed: 1, cargo: 6,  crew: 2, covet: 0, force: 0, price: 0 },
    { tier: 2, name: 'Dugout',     speed: 2, cargo: 10, crew: 3, covet: 1, force: 1, price: 8 },
    { tier: 3, name: 'Sail Canoe', speed: 3, cargo: 16, crew: 4, covet: 2, force: 1, price: 20 },
    { tier: 4, name: 'Cutter',     speed: 4, cargo: 26, crew: 6, covet: 4, force: 2, price: 45 },
    { tier: 5, name: 'Schooner',   speed: 5, cargo: 40, crew: 9, covet: 7, force: 3, price: 90 },
];

// ---- Zones (escalation tied to distance, not time) ----
const ZONES = [
    { start: 0,   name: 'The Delta',            polityChance: 0.45, deadStone: 0.05, current: 0, pirateForce: 3,  temperW: { open: 6, wary: 3, hostile: 1 } },
    { start: 30,  name: 'The Green Banks',      polityChance: 0.40, deadStone: 0.10, current: 0, pirateForce: 5,  temperW: { open: 4, wary: 4, hostile: 2 } },
    { start: 80,  name: 'The Warring Reaches',  polityChance: 0.35, deadStone: 0.15, current: 1, pirateForce: 8,  temperW: { open: 2, wary: 4, hostile: 4 } },
    { start: 150, name: 'The Cold Marches',     polityChance: 0.25, deadStone: 0.30, current: 1, pirateForce: 11, temperW: { open: 2, wary: 5, hostile: 3 } },
    { start: 240, name: 'The Fog Walls',        polityChance: 0.18, deadStone: 0.45, current: 2, pirateForce: 15, temperW: { open: 1, wary: 4, hostile: 5 } },
    { start: 350, name: 'The Headwaters Gate',  polityChance: 0.12, deadStone: 0.60, current: 2, pirateForce: 20, temperW: { open: 1, wary: 3, hostile: 6 } },
];

// ---- Polity economies ----
// sellMult: what they pay for your luxuries. buys: what they offer (base prices).
const ECONOMIES = {
    tradehub:  { name: 'Trade Hub',  color: '#c9a227', sellMult: { cigars: 1.0, liquor: 1.0, cloth: 1.0, dreamgum: 1.0, lighter: 1.2 },
                 buys: { food: 1, weapons: 3, rumor: 4, language: 6 }, recruitW: 3, thiefW: 2 },
    builder:   { name: 'Builder',    color: '#8a6b3f', sellMult: { cigars: 0.8, liquor: 1.0, cloth: 2.0, dreamgum: 0.8, lighter: 1.0 },
                 buys: { food: 2, weapons: 4, boat: 1, language: 8 }, recruitW: 1, thiefW: 1 },
    theocracy: { name: 'Theocracy',  color: '#7b6bb5', sellMult: { cigars: 0.8, liquor: 0.5, cloth: 1.2, dreamgum: 0, lighter: 1.0 },
                 buys: { food: 2, heal: 3, language: 3 }, recruitW: 1, thiefW: 0, bansGum: true },
    warlord:   { name: 'Warlord',    color: '#b54a3c', sellMult: { cigars: 1.2, liquor: 1.5, cloth: 0.8, dreamgum: 1.0, lighter: 1.5 },
                 buys: { food: 2, weapons: 2, language: 8 }, recruitW: 2, thiefW: 1, tolls: true },
    slaver:    { name: 'Slaver',     color: '#5e5e66', sellMult: { cigars: 1.5, liquor: 1.5, cloth: 1.5, dreamgum: 1.5, lighter: 2.0 },
                 buys: { food: 1, weapons: 3, rumor: 3, language: 8 }, recruitW: 1, thiefW: 2, pressgang: true },
};
const ECONOMY_IDS = ['tradehub', 'builder', 'theocracy', 'warlord', 'slaver'];
// weights by zone index: slavers and warlords thicken upriver
const ECONOMY_W = [
    [4, 2, 2, 1, 1],
    [3, 2, 2, 2, 1],
    [2, 2, 1, 3, 2],
    [2, 2, 1, 3, 2],
    [1, 1, 1, 3, 3],
    [1, 1, 1, 2, 3],
];

const TEMPERS = {
    open:    { name: 'Open',    tollW: 0, pressMult: 0.5, priceMult: 1.0 },
    wary:    { name: 'Wary',    tollW: 1, pressMult: 1.0, priceMult: 1.2 },
    hostile: { name: 'Hostile', tollW: 3, pressMult: 1.5, priceMult: 1.5 },
};

// ---- Language families and polity name fragments ----
const LANG_FAMILIES = [
    { id: 'esperic',  name: 'Esperic',  pre: ['Par', 'Nov', 'Lib', 'Vent', 'Mir'],       suf: ['olando', 'aterra', 'ova', 'esse', 'ora'] },
    { id: 'sinitic',  name: 'Sinitic',  pre: ['Tian', 'Shu', 'Wei', 'Lan', 'Hai'],       suf: ['guo', 'zhou', 'men', 'jiang', 'ling'] },
    { id: 'nilotic',  name: 'Nilotic',  pre: ['Kem', 'Nub', 'Ax', 'Mer', 'Sab'],         suf: ['ara', 'ossos', 'ubia', 'oe', 'anni'] },
    { id: 'norsic',   name: 'Norsic',   pre: ['Thor', 'Skag', 'Ulf', 'Grim', 'Vind'],    suf: ['heim', 'strand', 'fjall', 'garth', 'vik'] },
    { id: 'quechuan', name: 'Quechuan', pre: ['Inti', 'Wam', 'Quill', 'Pach', 'Cus'],    suf: ['antu', 'apata', 'acocha', 'amarca', 'aylla'] },
    { id: 'turkic',   name: 'Turkic',   pre: ['Alt', 'Kara', 'Tem', 'Bay', 'Ord'],       suf: ['ai', 'khanate', 'ur', 'tau', 'obruk'] },
];

// ---- Crew: the historical dead. One roster, ten abilities, no snowflakes. ----
const ABILITIES = {
    fighter:      { name: 'Fighter',      desc: '+2 force' },
    pilot:        { name: 'Pilot',        desc: '+1 boat speed' },
    linguist:     { name: 'Linguist',     desc: 'language lessons take 1 day; +10% trade' },
    quartermaster:{ name: 'Quartermaster',desc: '+4 cargo' },
    watchman:     { name: 'Watchman',     desc: 'night thieves always fail' },
    healer:       { name: 'Healer',       desc: '+1 HP every 2 days' },
    boatwright:   { name: 'Boatwright',   desc: 'storms never damage; free repairs' },
    orator:       { name: 'Orator',       desc: 'recruits and bribes cost 25% less' },
    angler:       { name: 'Angler',       desc: '+1 food per day in the wilds' },
    liberator:    { name: 'Liberator',    desc: '+25% to escape rolls' },
};

const CREW_ROSTER = [
    { name: 'Miyamoto Musashi',     ability: 'fighter' },
    { name: 'Joan of Arc',          ability: 'fighter' },
    { name: 'Spartacus',            ability: 'fighter' },
    { name: 'Boudica',              ability: 'fighter' },
    { name: 'Ching Shih',           ability: 'fighter' },
    { name: 'Mark Twain',           ability: 'pilot' },
    { name: 'Zheng He',             ability: 'pilot' },
    { name: 'Amelia Earhart',       ability: 'pilot' },
    { name: 'Richard Francis Burton', ability: 'linguist' },
    { name: 'Sequoyah',             ability: 'linguist' },
    { name: 'Hypatia of Alexandria',ability: 'linguist' },
    { name: 'Ibn Battuta',          ability: 'quartermaster' },
    { name: 'Marco Polo',           ability: 'quartermaster' },
    { name: 'Nellie Bly',           ability: 'quartermaster' },
    { name: 'Eugène Vidocq',        ability: 'watchman' },
    { name: 'Hattusili the Scribe', ability: 'watchman' },
    { name: 'Florence Nightingale', ability: 'healer' },
    { name: 'Sun Simiao',           ability: 'healer' },
    { name: 'Isambard Brunel',      ability: 'boatwright' },
    { name: 'Wang Zhenyi',          ability: 'boatwright' },
    { name: 'Cicero',               ability: 'orator' },
    { name: 'Sojourner Truth',      ability: 'orator' },
    { name: 'Izaak Walton',         ability: 'angler' },
    { name: 'Ernest Hemingway',     ability: 'angler' },
    { name: 'Harriet Tubman',       ability: 'liberator' },
    { name: 'Toussaint Louverture', ability: 'liberator' },
];

// ---- Milestone boons (permanent; survive translation) ----
const BOONS = {
    twiceblessed: { name: 'Twice-Blessed Grail',  desc: 'Your grail yields two luxuries each day.' },
    strangersmark:{ name: "The Stranger's Mark",  desc: 'Translations land in the upper half of your known river.' },
    compartment:  { name: 'Hidden Compartment',   desc: 'Keep 5 food and 3 luxuries through death.' },
    oldsoldier:   { name: "Old Soldier's Memory", desc: '+2 force, always.' },
    tongues:      { name: 'Gift of Tongues',      desc: 'Every polity counts as speaking your language.' },
    riversense:   { name: 'River Sense',          desc: 'The next 3 reaches are always charted.' },
};
const BOON_IDS = Object.keys(BOONS);

// Base prices (in barter value) before temper/language multipliers
const PRICES = {
    food: 1,        // per unit
    weapons: 3,     // per unit
    rumor: 5,       // charts 6 reaches ahead
    language: 10,   // a course of lessons (3 days, 1 with linguist)
    heal: 2,        // per HP
    recruit: 6,     // hiring gift
};

const RUMOR_RANGE = 6;
const MAX_HP = 3;
