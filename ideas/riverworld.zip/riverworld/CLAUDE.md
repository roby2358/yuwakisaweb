# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in
this repository.

## Project Overview

**Riverworld** is a browser journey game after Philip José Farmer: a 1-D infinite
river of "reaches," traveled one day per turn, with **no win and no game over**.
Death is translation — material progress (boat, crew, cargo) resets; knowledge (the
chart, languages, milestone boons) persists forever. Built for long-term recurring
play against a localStorage save.

Authoritative gameplay docs: `README.md` (intent + how to play), `DYNAMICS.md`
(theme, drivers, mechanics, strategies, tuning). Update DYNAMICS.md when mechanics
change — it is the record of *why*, not just *what*.

## Running / Developing

No build or install step. Scripts load as plain globals, so you can **double-click
`index.html` to run from `file://`**. No tests — this is a playtest-driven prototype;
verify with the headless Node sim (below) plus a browser playtest. No save-game
migration: schema changes may just break old saves.

Headless verification (the engine is DOM-free by design): concatenate
`rando.js data.js river.js state.js engine.js` into a `vm.runInThisContext` context
and drive a scripted bot through a few hundred days, asserting invariants (cargo/crew
within capacity, roster conservation across crew/lostSouls/recruitPool, hp sanity,
determinism of `generateReach`).

## Architecture

Plain `<script>` globals in dependency order (see `index.html`):

| File | Role |
|---|---|
| `rando.js` | Seeded RNG: `rando()` mutable stream (mulberry32) for live play; `hashRand(seed, index, salt)` pure hash for anything that must be deterministic per reach — river generation, dock offers, boon pairs. |
| `data.js` | Content tables: `LUXURIES`, `BOATS`, `ZONES`, `ECONOMIES`×`TEMPERS` (the polity template), `LANG_FAMILIES`, `CREW_ROSTER` (historical dead, one of ten `ABILITIES` each), `BOONS`, `PRICES`. |
| `river.js` | The River as a pure function: `generateReach(seed, i)` never stored; `actualReach` = bones + `state.riverMut` drift overlay; `chartReach` snapshots into `state.chart`; `chartStale` detects arrival surprises. |
| `state.js` | `newState` — the whole game in one serializable struct — plus localStorage save/load. |
| `engine.js` | DOM-free rules: the day wrapper (`advanceDay`: morning grail → action → evening event → world drift), travel with toll/milestone interception (`stepInto`), port actions (`act*`), fight resolution, slavery, `translate()` (death), the serializable event registry (`EVENTS` — pendingEvent stores `{id, params}` only; choices rebuilt via `describePendingEvent`), boons. |
| `ui.js` | Canvas river-ribbon chart (fog for uncharted, economy colors, temper borders, milestone stars) + HTML panels; full re-render from state; one delegated click handler dispatching `data-action` attributes. |
| `index.js` | Bootstrap: resume save or wake a new life. |

Engine invariants worth preserving:

- **Every crew member is in exactly one of** `state.crew` / `state.lostSouls` /
  `state.recruitPool`. Losing crew (pirates, enslavement, death) moves them to
  `lostSouls`, from which the drifter/reunion event returns them. Never delete one.
- **Losing the boat loses the hold and scatters the crew** — cargo/crew capacity must
  hold after any boat-tier change (only quartermaster loss may briefly overflow cargo).
- **Barter has no coin**: there is deliberately no sell action; luxuries convert to
  goods only inside `spendValue` at local sell rates. The "purse" is a valuation.
- **`state.pendingEvent` must stay JSON-serializable** — `{id, params}` only, never
  functions; rebuild UI choices through the `EVENTS` registry.
- **`translate()` sets `state.justTranslated`**, which forfeits the rest of the day in
  `advanceDay` — dying in the morning must not let the day's action run at the
  resurrection point.
- Actions return `false` when refused; a player must never be *stuck* (e.g. repair is
  always free and always available so a broke sailor is slow, not trapped).

## Conventions

- Pure client-side, plain globals, no ES modules, no npm, no bundler, no tests.
- Keep `engine.js`/`river.js`/`state.js`/`data.js`/`rando.js` free of DOM references
  so headless sims keep working.
- Tune numbers by halve-and-double first; tuning rationale lives in DYNAMICS.md.
